import matplotlib.pyplot as plt
x =[1,2,3,4,5]
y =[5,15,15,20,10]
plt.plot(x,y)


plt.show()

